#ifndef __EXTI_H__
#define __EXTI_H__

#include "stm32f10x.h"

extern unsigned int Num;

void EXTI1_Init(void);//外部中断1初始化(PA1 EXTI1)

#endif
