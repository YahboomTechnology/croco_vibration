#include "EXTI.h"

unsigned int Num = 0;

void EXTI1_Init(void)//外部中断1初始化(PA1 EXTI1)
{
   EXTI_InitTypeDef   EXTI_InitStructure;
   GPIO_InitTypeDef   GPIO_InitStructure;
   NVIC_InitTypeDef   NVIC_InitStructure;
    
   /* Enable GPIOA and AFIO clock */
   /* 使能GPIOA AFIO时钟 */
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    
   /* Configure PA1 pin as input floating */
   /* 配置PA1上拉输入模式 */
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
   GPIO_Init(GPIOA, &GPIO_InitStructure);
    
   /* Connect EXTI1 Line to PA1 pin */
   /* 连接EXTI1到PA1引脚 */
   GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource1);
 
   /* Configure EXTI1 line */
   /* 配置EXTI1 */
   EXTI_InitStructure.EXTI_Line = EXTI_Line1;
   EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
   EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
   EXTI_InitStructure.EXTI_LineCmd = ENABLE;
   EXTI_Init(&EXTI_InitStructure);
 
   /* Enable and set EXTI1 Interrupt to the lowest priority */
   /* 使能和配置EXTI1优先级及中断向量入口地址 */
   NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
   NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
   NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
   NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
   NVIC_Init(&NVIC_InitStructure);
}

 void EXTI1_IRQHandler(void)
 {
   if(EXTI_GetITStatus(EXTI_Line1) != RESET)
   {
			Num++;
			/* Clear the  EXTI line 1 pending bit */
			/* 清除EXTI1中断标志位 */
			EXTI_ClearITPendingBit(EXTI_Line1);
   }
}
