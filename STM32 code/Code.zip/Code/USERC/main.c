#include "stm32f10x.h"
#include "LED.h"
#include "EXTI.h"

int main(void)
{
    LED_Init();//LED初始化(PB4)
    EXTI1_Init();//外部中断1初始化(PA1 EXTI1)
    
    while(1)
    { 
			
			if(Num >= 5)
		 {
				Num = 0;
				/* Toggle LED(PB4) */
				/* 反转LED(PB4)状态 */
				GPIO_WriteBit(GPIOB, GPIO_Pin_4, (BitAction)(1 - GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_4)));
		 }
    }
}
